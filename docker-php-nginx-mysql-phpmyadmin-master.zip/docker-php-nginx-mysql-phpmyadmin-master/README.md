# docker-php-nginx-mysql-phpmyadmin
project ตัวอย่างจากบทความ 

ทำไมถึงเลิกใช้ xampp มาใช้ Docker - Part 2: Deploy website with php, mysql, nginx and phpmyadmin

https://www.naijab.com/why-use-docker-not-xampp-part-2/

## How to use

1. clone หรือ download repo นี้ลงเครื่อง
2. cd ไปที่ตำแหน่งของ project ที่ clone ไว้ 
3. จากนั้นใช้คำสั่ง docker-compose up -d 
